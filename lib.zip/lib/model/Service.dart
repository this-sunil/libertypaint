class Service{
  String title;
  String imagePath;


  Service(this.title,this.imagePath);
}