// To parse this JSON data, do
//
//     final errorDetailsModel = errorDetailsModelFromJson(jsonString);

import 'dart:convert';

List<ErrorDetailsModel> errorDetailsModelFromJson(String str) => List<ErrorDetailsModel>.from(json.decode(str).map((x) => ErrorDetailsModel.fromJson(x)));

String errorDetailsModelToJson(List<ErrorDetailsModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ErrorDetailsModel {
  ErrorDetailsModel({
    required this.id,
    required this.errorName,
  });

  int id;
  String errorName;

  factory ErrorDetailsModel.fromJson(Map<String, dynamic> json) => ErrorDetailsModel(
    id: json["error_id"],
    errorName: json["error_name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "error_name": errorName,
  };
}
