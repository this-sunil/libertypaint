//

import 'package:flutter/cupertino.dart';

final Ccolor = const Color(0xff622141);
// import 'dart:js';
//
// import 'package:flutter/material.dart';
// late  Text text;
// Widget appBars=
//

// Widget AppBars= appBar(
//   title: text,
//   leading: IconButton(
//     onPressed: (){
//       Navigator.pop(context);
//     },icon: Icon(Icons.chevron_left),
//   ),
//   backgroundColor: Colors.deepPurple,
//   //actions: [IconButton(onPressed: (){}, icon: Icon(Icons.more_vert))],
//
// );
