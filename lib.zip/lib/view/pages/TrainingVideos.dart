/*
import 'package:flutter/material.dart';
class TrainingVideos extends StatefulWidget {
  const TrainingVideos({Key? key}) : super(key: key);

  @override
  _TrainingVideosState createState() => _TrainingVideosState();
}

class _TrainingVideosState extends State<TrainingVideos> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text("Training Videos"),
      ),
      body: ,
    );
  }
}
*/
